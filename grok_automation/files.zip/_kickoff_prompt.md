# Claude Code Kickoff Prompt — Phase 1

> **Cách dùng**: Copy nội dung dưới (từ "===== START =====" đến "===== END =====") rồi paste vào Claude Code session sau khi `cd` vào folder project.

===== START =====

I'm building `grok_automation` — a PyQt6 desktop app to automate Grok image/video generation via Patchright connected to existing Chrome browser via CDP.

**Reference docs in this folder (READ FIRST):**
- `CLAUDE.md` — full project context, conventions, selector mappings, what NOT to do
- `flow_spec.md` — detailed flow specifications for all 4 modes
- `examples/*.json` — example input files
- `launch_chrome.bat` — Chrome launcher with debug port 9222

**Phase 1 scope (DO ONLY THIS, nothing more):**

1. **Project structure**: Init uv project, set up folders per CLAUDE.md
2. **Dependencies**: PyQt6, patchright, qasync, pydantic, loguru. Add to pyproject.toml via `uv add`
3. **`grok/browser.py`**: BrowserManager class
   - `connect(cdp_url)` → connect via Patchright CDP
   - `list_tabs()` → return list of dicts `[{index, url, title}]`
   - `select_tab(index)` → store as active page
   - `disconnect()` → cleanup
4. **`ui/main_window.py`**: MainWindow shell
   - Single panel for now: ConnectionPanel
   - Window title "Grok Automation", size 900x700
5. **`ui/panels.py`**: ConnectionPanel widget
   - Input field for CDP URL (default `http://localhost:9222`)
   - "Connect" button → calls BrowserManager.connect via worker
   - QComboBox listing available tabs (populated after connect)
   - "Refresh tabs" button
   - Status label (Disconnected / Connected / Error)
6. **`workers/automation_worker.py`**: QThread + qasync bridge
   - Helper to run async functions from Qt UI signals
7. **`main.py`**: Entry point
   - Create QApplication + qasync event loop
   - Show MainWindow

**Constraints (from CLAUDE.md):**
- Async only for Patchright (no sync API)
- UI strings in Vietnamese
- Code/comments/docstrings in English
- Use loguru for logging
- Don't crash UI on errors — catch and show in status

**Phase 1 acceptance test:**
1. Launch Chrome via `launch_chrome.bat` (already provided)
2. `uv run python main.py`
3. Click Connect → status shows "Connected"
4. Dropdown lists tabs including `grok.com/imagine`
5. Select tab → status shows selected tab title
6. Click Disconnect → cleanup OK

**Don't do yet (Phase 2+):**
- selectors.py
- actions.py / runner.py / flows.py
- Any actual Grok automation
- Project/Generation/Run panels
- Download handling

Start by reading CLAUDE.md and flow_spec.md, then propose the file creation order before writing code. I want to review your plan first.

===== END =====
